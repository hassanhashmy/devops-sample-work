import os


def lambda_handler(event, context):
    return "This is from Lambda!"